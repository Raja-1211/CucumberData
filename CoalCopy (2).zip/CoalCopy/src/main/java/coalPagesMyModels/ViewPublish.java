package coalPagesMyModels;

import coalBase.BaseMethods;

public class ViewPublish extends BaseMethods
{

	public void operationWC()
	{
		
	}
	
	public void outputReports()
	{
		
	}
	
	public void Documents()
	{
		
	}
	
	public void exportToExcel()
	{
		
	}
	
	public void exportJsonToScg()
	{
		
	}
	
	
		
}
