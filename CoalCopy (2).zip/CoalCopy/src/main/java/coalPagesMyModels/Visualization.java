package coalPagesMyModels;

import coalBase.BaseMethods;

public class Visualization extends BaseMethods
{

	public void capacityChart()
	{
		
	}
	
	public void workCenterPoolChart()
	{
		
	}
	
	public void ExtendedValueStream()
	{
		
	}
	
	public void scenarioComapare()
	{
		
	}
	
	public void cagr()
	{
		
	}
	
	public void daysOfInventory()
	{
		
	}
	
		
}
