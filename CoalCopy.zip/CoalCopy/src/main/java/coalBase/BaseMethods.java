package coalBase;

import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * This class contains the BaseMethods which will be used frequently in the entire framework
 * @author Raja
 */

public class BaseMethods
{
	public WebDriver driver;
	public String usrnme;
	public String pswd;
	public Properties prop;
	public String browser;
	
	/**
	 * This method will launch the Chrome or IE browser
	 * Load the url
	 * Maximise the browser and set the wait for 20 seconds
	 * @parameter browser - This will load the specified browser  
	 * @throws WebDriverException 
	 * @author Raja
	 */
	
	public void startApplication(String browser)
	{
		try {
		if(browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Raja.k\\git\\Coalrepository\\CoalCopy\\chromedriver_win32\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-extensions");
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("IE"))
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Raja.k\\eclipse-workspace\\Coal\\IEDriverServer_x64_3.14.0\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.get("https://qa-coal.mmm.com");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		}catch (WebDriverException  e) {			
			System.out.println("The browser: "+ browser +" could not be launched");
		}
	}

	/**
	 * This method will locate the element using any given locator
	 * @param locator - The locator by which the element to be found
	 * @param locValue - The locator value by which the element to be found
	 * @throws NoSuchElementException and WebDriverException
	 * @author Raja
	 */
	
     public WebElement locateElement(String locator, String locValue) 
 	{
 		try {
 			switch(locator) {
 			case("id"):
 			return driver.findElement(By.id(locValue));
 			case("link"): return driver.findElement(By.linkText(locValue));
 			case("xpath"):return driver.findElement(By.xpath(locValue));
 			case("name"): return driver.findElement(By.name(locValue));
 			case("class"): return driver.findElement(By.className(locValue));
 			case("tag"):return driver.findElement(By.tagName(locValue));
 			}
 		} catch (NoSuchElementException e) {
 			System.out.println("The element with locator "+locator+" not found.");
		} catch (WebDriverException e) {
			System.out.println("Unknown exception occured while finding "+locator+" with the value "+locValue);
		}
 		return null;
 	}
     
     public void type(WebElement ele, String data) {
 		try {
 			ele.clear();
 			ele.sendKeys(data);
 			String x = ""+ele;
 			//reportStep("The data: "+data+" entered successfully in the field :"+ele, "PASS");
 		} catch (InvalidElementStateException e) {
 			//reportStep("The data: "+data+" could not be entered in the field :"+ele,"FAIL");
 		} catch (WebDriverException e) {
 			//reportStep("Unknown exception occured while entering "+data+" in the field :"+ele, "FAIL");
 		}
 	}

 	public void click(WebElement ele) {
 		String text = "";
 		try {
 			WebDriverWait wait = new WebDriverWait(driver, 10);
 			wait.until(ExpectedConditions.elementToBeClickable(ele));			
 			text = ele.getText();
 			ele.click();
 			//reportStep("The element "+text+" is clicked", "PASS");
 		} catch (InvalidElementStateException e) {
 			//reportStep("The element: "+text+" could not be clicked", "FAIL");
 		} catch (WebDriverException e) {
 			//reportStep("Unknown exception occured while clicking in the field :", "FAIL");
 		} 
 	}
 	
 	public void acceptAlert() {
		String text = "";		
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.accept();
			//reportStep("The alert "+text+" is accepted.","PASS");
		} catch (NoAlertPresentException e) {
			//reportStep("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			//reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		}  
	}

	public void dismissAlert() {
		String text = "";		
		try {
			Alert alert = driver.switchTo().alert();
			text = alert.getText();
			alert.dismiss();
			//reportStep("The alert "+text+" is dismissed.","PASS");
		} catch (NoAlertPresentException e) {
			//reportStep("There is no alert present.","FAIL");
		} catch (WebDriverException e) {
			//reportStep("WebDriverException : "+e.getMessage(), "FAIL");
		} 
	}
	
}


 	