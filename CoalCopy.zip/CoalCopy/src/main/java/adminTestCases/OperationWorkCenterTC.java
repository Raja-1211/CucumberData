package adminTestCases;

import coalBase.BaseMethods;

public class OperationWorkCenterTC extends BaseMethods
{
	
	
}
