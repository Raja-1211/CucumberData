package adminTestCases;

import org.openqa.selenium.By;

import coalBase.BaseMethods;

public class OperationWorkCenterTC extends BaseMethods
{
	
	public void startt() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Operation | Work Center')]")).click();	
	}
	
	
}
