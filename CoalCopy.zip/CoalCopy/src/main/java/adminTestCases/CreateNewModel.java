package adminTestCases;

import coalBase.BaseMethods;

public class CreateNewModel extends BaseMethods

{

}
