package adminTestCases;

import coalBase.BaseMethods;

public class ManufacturingRelationshipTC extends BaseMethods
{

	
	
	
}
