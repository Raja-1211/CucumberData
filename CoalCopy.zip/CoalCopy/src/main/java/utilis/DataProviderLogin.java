package utilis;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import adminTestCases.LoginTC;

/**
 * This class contains the Data Provider method which will fetch the data from the excel and pass the data to the respective methods
 * @author Raja
 */

public class DataProviderLogin extends LoginTC
{
	
	/**
	 * This method will fetch the data from the excel and pass the data to the respective methods
	 * Load the excel file
	 * Pass the values in the sheet to the respective methods using for loop
	 * @author Raja
	 * @throws IOException, NullPointerException and Exception
	 */
	
	public static int rowCount;
	public static String[][] readInput() throws IOException
	{
		String[][] data = null;

		try{
			FileInputStream fis = new FileInputStream(new File("C:\\Users\\Raja.k\\git\\Coalrepository\\Coal\\ExcelData\\DataExcelImport.xlsx"));
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
			rowCount = sheet.getLastRowNum();
			int columnCount = sheet.getRow(2).getLastCellNum();
			data = new String[rowCount][columnCount];
			
			for (int i = 2; i<rowCount+1; i++) {
				try {
					XSSFRow row = sheet.getRow(i);
				
					for (int j = 0; j<columnCount; j++) {
						try {
							String cellValue = "";
							try {
								cellValue = row.getCell(j).getStringCellValue();
								System.out.println(cellValue);
							} catch (NullPointerException e) {

							}
							data[i-1][j] = cellValue;
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			fis.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
}

