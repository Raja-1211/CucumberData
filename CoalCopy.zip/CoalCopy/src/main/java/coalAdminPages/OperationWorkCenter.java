package coalAdminPages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminTestCases.ManufacturingRelationshipTC;
import coalBase.BaseMethods;

public class OperationWorkCenter extends BaseMethods
{
	public OperationWorkCenter(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void operationName(String data1) throws InterruptedException
	{
		//Add button
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[1]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
		Thread.sleep(1000);
	}
	
	public void operationSName(String data2) throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(1000);
	}
	public void operationRegion(String data3) throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span")).click();
		Thread.sleep(1000);
		if(data3.equalsIgnoreCase("ASIA"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'ASIA')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'AUSTRALIA')]")).click();	
		}
	}
	
	public void operationGroupName(String data4) throws InterruptedException
	{
	
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[9]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data4.equalsIgnoreCase("Clean coating"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Clean coating')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'Assembly')]")).click();
		}
		Thread.sleep(2000);
		
	}
	
	public void operationTypeName(String data5) throws InterruptedException
	{
	
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[10]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data5.equalsIgnoreCase("Assembly Type"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Assembly Type')]")).click();
		}
		Thread.sleep(2000);
	}
	
	public void operationDivisionName(String data6) throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[11]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data6.equalsIgnoreCase("3M Ventures"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'3M Ventures')]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();	
	}
	
	public void operationGroup(String data7) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(5000);
		//Add Button
		driver.findElement(By.xpath("//*[@id='operationGroupGrid']/div[1]/a")).click();	
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='OperationGroupName']")).sendKeys(data7);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='operationGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void operationType(String data8) throws InterruptedException
	{
		//Add Button 
		driver.findElement(By.xpath("//*[@id='operationTypeGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='OperationTypeName']")).sendKeys(data8);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='operationTypeGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();		
	}
	
	public void workCenterName(String data1) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(2000);
		//Add button		
		driver.findElement(By.xpath("//*[@id='MasterWorkCenterGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
		Thread.sleep(2000);
	}
	
	public void workCenterSName(String data2) throws InterruptedException
	{
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='MasterWorkCenterGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void unitConversionlevel(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='btnUnitConv']")).click();
		Thread.sleep(2000);
		Select conversionlevel = new Select(driver.findElement(By.xpath("//*[@id='UnitConversionLevelStaticSequenceNumber']")));
		conversionlevel.selectByVisibleText("Global");
	}
	
	public void unitConversionWC(String data2) throws InterruptedException
	{	
		Thread.sleep(3000);
		Select workcenter = new Select(driver.findElement(By.xpath("//*[@id='WorkCenterID']")));
		//Thread.sleep(3000);
		//if(data2.equalsIgnoreCase("Mumbai"))
		//{
		workcenter.selectByVisibleText("Korea");
		//}
	}
	
	public void unitConversionFunit(String data3) throws InterruptedException
	{
		Thread.sleep(3000);
		Select fromunit = new Select(driver.findElement(By.xpath("//*[@id='FromUOMID']")));
		//Thread.sleep(3000);
		//if(data3.equalsIgnoreCase("EACH"))
		//{
		fromunit.selectByVisibleText("EACH");
		//Thread.sleep(3000);
		//}
	}
	
	public void unitConversionTunit(String data4) throws InterruptedException
	{
		Select tounit = new Select(driver.findElement(By.xpath("//*[@id='ToUOMID']")));
		//Thread.sleep(3000);
		//if(data4.equalsIgnoreCase("EACH"))
		//{
		tounit.selectByVisibleText("EACH");
		//}
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='formCreateEditUC']/div[3]/table/tbody/tr/td[1]/input")).click();
	}
	
	public void unitConversionCFactor() throws InterruptedException
	{
		/*driver.findElement(By.xpath("//*[@id='ConversionFactor']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='ConversionFactor']")).sendKeys(data5);*/
		Thread.sleep(3000);
		//Save
		driver.findElement(By.xpath("//*[@id='formCreateEditUC']/div[3]/table/tbody/tr/td[1]/input")).click();	
	}
	
	public ManufacturingRelationshipTC manufacturingRelationship() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Manufacturing Relationship (MR)')]"));
		return new ManufacturingRelationshipTC();
	}
	
	
}
