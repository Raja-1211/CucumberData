package coalAdminPages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminTestCases.ManufacturingRelationshipTC;
import coalBase.BaseMethods;

public class OperationWorkCenter extends BaseMethods
{

	
	
	public OperationWorkCenter(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void operation(String data1,String data2,String data3,String data4,String data5,String data6) throws InterruptedException
	
	{
		//Add button		
		driver.findElement(By.xpath("//a[@href='/Site/Site_Read?SiteGrid-mode=insert']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span")).click();
		Thread.sleep(1000);
		if(data3.equalsIgnoreCase("ASIA"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'ASIA')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'AUSTRALIA')]")).click();	
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[9]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data4.equalsIgnoreCase("Clean coating"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Clean coating')]")).click();
		}else {
			driver.findElement(By.xpath("//li[contains(text(),'Assembly')]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[10]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data5.equalsIgnoreCase("Assembly Type"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Assembly Type')]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[11]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data6.equalsIgnoreCase("3M Ventures"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'3M Ventures')]")).click();
		}
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='SiteGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();	
	}
	
	public void operationGroup(String data1) throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,400)");
		Thread.sleep(5000);
		//Add Button
		driver.findElement(By.xpath("//a[@href='/OperationGroup/OperationGroup_Read?operationGroupGrid-mode=insert']")).click();	
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='OperationGroupName']")).sendKeys(data1);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='operationGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void operationType(String data1) throws InterruptedException
	{
		//Add Button 
		driver.findElement(By.xpath("//a[@href='/OperationType/OperationType_Read?operationTypeGrid-mode=insert']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='OperationTypeName']")).sendKeys(data1);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='operationTypeGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();		
	}
	
	public void workCenter(String data1,String data2) throws InterruptedException
	{
		Thread.sleep(3000);
		//Add button		
		driver.findElement(By.xpath("//a[@href='/WorkCenter/WC_Read?MasterWorkCenterGrid-mode=insert']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='ShortName']")).sendKeys(data2);
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='MasterWorkCenterGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	public void unitConversion(String data1, String data2, String data3, String data4, String data5) throws InterruptedException
	{
		
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,1000)");
		driver.findElement(By.xpath("//button[@id='btnUnitConv']")).click();
		Thread.sleep(3000);
		Select conversionlevel = new Select(driver.findElement(By.xpath("//select[@id='UnitConversionLevelStaticSequenceNumber']")));
		Thread.sleep(3000);
		if(data1.equalsIgnoreCase("Global"))
		{
		conversionlevel.selectByVisibleText("Global");
		}
		Thread.sleep(3000);
		Select workcenter = new Select(driver.findElement(By.xpath("//select[@id='WorkCenterID']")));
		Thread.sleep(3000);
		if(data2.equalsIgnoreCase("Treater 1"))
		{
		workcenter.selectByVisibleText("215S");
		}
		Thread.sleep(3000);
		Select fromunit = new Select(driver.findElement(By.xpath("//select[@id='FromUOMID']")));
		Thread.sleep(3000);
		if(data3.equalsIgnoreCase("EACH"))
		{
		fromunit.selectByVisibleText("EACH");
		Thread.sleep(3000);
		}
		Select tounit = new Select(driver.findElement(By.xpath("//select[@id='ToUOMID']")));
		Thread.sleep(3000);
		if(data4.equalsIgnoreCase("EACH"))
		{
		tounit.selectByVisibleText("EACH");
		}
		Thread.sleep(3000);
		//Conversion Factor
		driver.findElement(By.xpath("//input[@id='ConversionFactor']")).clear();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='ConversionFactor']")).sendKeys(data5);
		Thread.sleep(3000);
		//Save
		driver.findElement(By.xpath("//input[@value='Save']")).click();	
	}
	
	public ManufacturingRelationshipTC manufacturingRelationship() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Manufacturing Relationship (MR)')]"));
		return new ManufacturingRelationshipTC();
	}
	
	
}
