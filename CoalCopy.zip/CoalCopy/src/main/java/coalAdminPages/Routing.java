package coalAdminPages;

import org.openqa.selenium.By;

import coalBase.BaseMethods;

public class Routing extends BaseMethods
{
	public void routingtext()
	{
		driver.findElement(By.xpath("//a[contains(text(),'Routing')]")).click();
	}
	
	public void routingAddbtn()
	{
		driver.findElement(By.xpath("//a[@onclick='LoadRoutingCreate();']")).click();
	}
	
	public void routeName()
	{
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("");
	}
	
	public void routeProductFamily(String data1, String data2)
	{
		if(data1.equalsIgnoreCase("Product Family"))
		{
		driver.findElement(By.xpath("//input[@name='AutoProductFamily']")).sendKeys("");
		}
		else if(data2.equalsIgnoreCase(data2))
		{
		driver.findElement(By.xpath("//input[@name='txtModelRouteFinishedGood']")).sendKeys("");
		}
	}
	
	
}
