package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import coalBase.BaseMethods;

public class Routing extends BaseMethods
{
	public void routingtext()
	{
		driver.findElement(By.xpath("//a[contains(text(),'Routing')]")).click();
	}
	
	public void routingAddbtn()
	{
		driver.findElement(By.xpath("//a[@onclick='LoadRoutingCreate();']")).click();
	}
	
	public void routeName()
	{
		driver.findElement(By.xpath("//input[@name='Name']")).sendKeys("");
	}
	
	public void routeProduct(String data1)
	{
		if(data1.equalsIgnoreCase("Product"))
		{
		driver.findElement(By.xpath("//input[@id='rbProduct']")).click();
		driver.findElement(By.xpath("//input[@id='txtModelRouteFinishedGood']")).sendKeys("");
		}
		else if(data1.equalsIgnoreCase("Product Family"))
		{
			driver.findElement(By.xpath("//input[@id='rbProductFamily']")).click();
			driver.findElement(By.xpath("//input[@name='AutoProductFamily']")).sendKeys("");
		}
	}
	
	public void routeStatus(String data1)
	{
		if(data1.equalsIgnoreCase("Active"))
		{
		Select active = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
		active.selectByVisibleText("Active");
		}
		else if(data1.equalsIgnoreCase("InActive"))
		{
			Select inactive = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
			inactive.selectByVisibleText("InActive");
		}
		else if(data1.equalsIgnoreCase("InProgress"))
		{
			Select inprogress = new Select(driver.findElement(By.xpath("//select[@id='Status']")));
			inprogress.selectByVisibleText("InProgress");
		}
	}
	
	public void isTemplate(String data1)
	{
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsTemplate']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{
		}
	}
	
	public void needFocusFactory(String data1)
	{
		if(data1.equalsIgnoreCase("yes"))
		{
			driver.findElement(By.xpath("//input[@id='IsFocusFactoryNeeded']")).click();
		}else if(data1.equalsIgnoreCase("No"))
		{	
		}
	}
	
	public void saveButton()
	{
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}
	
	public void cancelbutton()
	{
		driver.findElement(By.xpath("//input[@id='btnCancel']")).click();
	}
	
	public void expandAll()
	{
		driver.findElement(By.xpath("//input[@id='btnExpandOrCollapseAll']")).click();
	}
	
	
	
	
}
