package coalAdminPages;

import org.openqa.selenium.By;

import coalBase.BaseMethods;

public class ManufacturingRelationship extends BaseMethods
{

	public void manufacturingRelationshipadd()
	{
		driver.findElement(By.xpath("//*[@id='divBillOfMaterial']/div[1]/div/a")).click();
		driver.findElement(By.xpath("//a[@onclick='LoadBillOfMaterialCreate();']")).sendKeys("");
	}
	
	public void productcheckbox(String data1, String data2)
	{
		if(data1.equalsIgnoreCase("Product"))
		{
		//driver.findElement(By.xpath("//input[@id='rdoProduct")).click();
		}
		else if(data1.equalsIgnoreCase("Product Family"))
		{
		driver.findElement(By.xpath("//input[@id='rdoFamily']")).click();
		}
	}
	
	public void manufacturingRelationship(String data1)
	{
		driver.findElement(By.xpath("//input[@id='autoList']")).sendKeys(data1);
	}
	
	public void MROperations(String data1)
	{
		driver.findElement(By.xpath("//input[@id='autoOperation']")).sendKeys(data1);
		driver.findElement(By.xpath("//input[@id='btnOpertation']")).click();
    }
	
	public void autoComponent(String data1)
	{
		driver.findElement(By.xpath("//input[@id='autoComponent']")).sendKeys(data1);
		driver.findElement(By.xpath("//input[@id='numQty']")).clear();
		driver.findElement(By.xpath("//input[@id='numQty']")).sendKeys("");
		driver.findElement(By.xpath("//input[@id='btnComponents']")).click();
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	}

}
