package coalAdminPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import coalBase.BaseMethods;

/**
 * This class contains the Methods to add the Customer, Currency, Region, Country, UoM and Divison
 * @author Raja & Babu
 */

public class BaseMaster extends BaseMethods
{		
	BaseMethods base = new BaseMethods();
	
	/**
	 * This method will initialize the web elements which are defined in Page Objects
	 * @author Raja
	 */
	
	public BaseMaster(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * This method will click the Add button in the Customer section
	 * @author Raja
	 * @throws InterruptedException 
	 */
	
	public void adminadd() throws InterruptedException
	{
		Thread.sleep(3000);
		//Name
		driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(text(),'Clear')]")).click();
		Thread.sleep(2000);
		//ShortName
		driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[8]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[24]/form/div[1]/div[2]/button[2]")).click();
		Thread.sleep(2000);	
		//Category
		driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[9]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[25]/form/div[1]/div[2]/button[2]")).click();
		Thread.sleep(2000);	
		//Add Button		
		driver.findElement(By.xpath("//a[@href='/Customer/Customer_Read?customerGrid-mode=insert']")).click();
	}
	
	/**
	 * This method will pass the Customer name in the Customer text field
	 * @param customername - This will pass the Customer Name data 
	 * @throws NullPointerException 
	 * @author Raja
	 * @throws InterruptedException 
	 */
	
	public void createCustomername(String data1) throws InterruptedException 
		{
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input[@class='text-box single-line' and @id='Name']")).sendKeys(data1);
		}
	
	/**
	 * This method will pass the Customer Short Name in the Customer text field
	 * @param customersnname - This will pass the Customer Short Name data 
	 * @throws NullPointerException
	 * @author Raja
	 * @throws InterruptedException 
	 */
	
	public void createCustomersnname(String data2) throws InterruptedException 
	{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@class='text-box single-line' and @id='ShortName']")).sendKeys(data2);
	}
	
	public void createCustomerCategory(String data3) throws InterruptedException 
	{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//span[@aria-owns='CategoryName_listbox' ]")).click();
			Thread.sleep(2000);
			if(data3.equalsIgnoreCase("External"))
			{
			driver.findElement(By.xpath("//li[contains(text(),'External')]")).click();
			}else
			{
			driver.findElement(By.xpath("//li[contains(text(),'Internal')]")).click();
			}
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
			Thread.sleep(2000);
	}
	
	/** This method will click the Filter icon and pass the newly created Customer Name. 
	 * This method will link the Newly created Customer Data with the Division
	 * @throws Exception
	 * @author Raja
	 */
	
	public void customerFilter(){
		try {
			Thread.sleep(2000);
			driver.findElement(By.xpath("//a[@role='button' and @class='k-button k-button-icontext k-primary k-grid-update']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@type='reset' and @class='k-button']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@class='k-textbox' and @title='Value']")).sendKeys("Customer-Sticky Coal");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[text()='Filter']")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='customerGrid']/div[3]/table/tbody/tr/td[5]/a")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='CustomerDivisionGrid']/div[1]/a")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='CustomerDivisionGrid']/div[3]/table/tbody/tr/td[7]/span[1]/span/span[2]/span")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//li[contains(text(),'3M IPC')]")).click();
			Thread.sleep(2000);
			} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/** This method will create the data in the Currency section
	 * @throws Exception
	 * @author Raja
	 */
	
	public void createCurrencyName(String data1)throws Exception
	{		
		Thread.sleep(4000);
		//Add Button
		driver.findElement(By.xpath("//*[@id='MasterCurrencyGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Name']")).sendKeys(data1);
		Thread.sleep(2000);
		}
		
	public void createCurrencySName(String data2)throws Exception
	{
	 driver.findElement(By.xpath("//input[@id='Description']")).sendKeys(data2);
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")).click();
	 Thread.sleep(2000);
	} 
	
	/**
	 * This method will create the data in the Region section
	 * @throws Exception
	 * @author Raja
	 */
	
	public void createRegionName(String data1)throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		js.executeScript("window.scrollBy(0,200)");
		Thread.sleep(4000);
		//Add button		
		driver.findElement(By.xpath("//*[@id='MasterRegionGrid']/div[1]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Name']")).sendKeys(data1);
		Thread.sleep(2000);
	}
	
	public void createRegionSName(String data2)throws Exception
	{
		driver.findElement(By.xpath("//input[@class='text-box single-line' and @name='Description']")).sendKeys(data2);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@class='k-button k-button-icontext k-primary k-grid-update']")).click();
		Thread.sleep(2000);	
	}
	
	/**
	 * This method will create the new Country in the Country section
	 * @throws Exception
	 * @author Babu
	 */
	
	 public void createCountryName(String data1) throws Exception
	 {
		 //Add Button		
		 driver.findElement(By.xpath("//a[@href='/Country/Country_Read?GridCountry-mode=insert']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id='Name']")).sendKeys(data1);
		 Thread.sleep(2000);
	 }
	 
	 public void createCountrySName(String data2) throws Exception
	 {
	 	driver.findElement(By.xpath("//input[@id='Code']")).sendKeys(data2);
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		WebElement servicedesk= driver.findElement(By.xpath(" //*[@id='GridCountry']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span"));
		action.moveToElement(servicedesk).click().build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'ASIA')]")).click();
		Thread.sleep(2000);
	 }
	 
	 public void createCountryLatitude(String data3) throws Exception
	 {
	 
		driver.findElement(By.xpath(" //input[@id='Latitude']")).sendKeys(data3);
		Thread.sleep(2000);
	 }
	 public void createCountryLongitude(String data4) throws Exception
	 {
		driver.findElement(By.xpath(" //input[@id='Longitude']")).sendKeys(data4);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='GridCountry']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);
	} 
	 
	 /**
		 * This method will create the new data in the UoM section
		 * @throws Exception
		 * @author Babu
		 */

	public void createUoMName(String data1) throws Exception
	{
		 //Add button		
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//a[@href='/UnitOfMeasurement/UoM_Read?UoMGrid-mode=insert']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}
	
	public void createUoMCode(String data2) throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Code']")).sendKeys(data2);
	}
	
	public void createUoMDescription(String data3) throws Exception
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Description']")).sendKeys(data3);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='UoMGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);
	} 
	
	 /**
	 * This method will link the Customer, Product and Work Center with the Division
	 * @throws Exception
	 * @author Babu
	 * @return 
	 */
	 
    public void linkDivision() throws Exception{
     try {
    	//Customer with division Mapping
    	Thread.sleep(2000);
        Actions action = new Actions(driver);
        Thread.sleep(2000);
        WebElement elecreatediv1= driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[1]/td[2]/a"));
    	action.moveToElement(elecreatediv1).click().build().perform();
    	Thread.sleep(2000);
    	WebElement elecreatediv2=driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[1]/td[2]/a"));
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        Thread.sleep(2000);
    	jse.executeScript("arguments[0].click();", elecreatediv2);
    	Thread.sleep(2000);
    	Actions action2 = new Actions(driver);
    	Thread.sleep(2000);
	    WebElement elecreatediv3= driver.findElement(By.xpath("//*[@id='DivisionCustomerGrid']/div[1]/a"));
	    Thread.sleep(2000);
		action2.moveToElement(elecreatediv3).click().build().perform();
		WebElement elecreatediv4=driver.findElement(By.xpath("//*[@id='DivisionCustomerGrid']/div[1]/a"));
		Thread.sleep(2000);
	    JavascriptExecutor jse2 = (JavascriptExecutor)driver;
	    Thread.sleep(2000);
	 	jse2.executeScript("arguments[0].click();", elecreatediv4); 
	 	Thread.sleep(2000);
	 	Actions action3 = new Actions(driver);
	 	Thread.sleep(2000);
		WebElement elecreatediv5= driver.findElement(By.xpath("//*[@id=\"DivisionCustomerGrid\"]/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span"));
		Thread.sleep(2000);
		action3.moveToElement(elecreatediv5).click().build().perform();	     
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'BABU')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"DivisionCustomerGrid\"]/div[3]/table/tbody/tr[1]/td[1]/a[1]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@id='btnBack']")).click();	 	
		Thread.sleep(2000);
    	//Product with division Mapping
		Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id='DivisionGrid']/div[3]/table/tbody/tr[1]/td[3]/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionProductMapGrid\"]/div[1]/a")).click();
    	Thread.sleep(2000);
    	
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionProductMapGrid\"]/div[1]/a")).click();
    	Thread.sleep(2000);	
		WebElement elecreatediv6= driver.findElement(By.xpath("//*[@id='DivisionProductMapGrid']/div[3]/table/tbody/tr/td[6]/span[1]/span/span[2]/span"));
		action3.moveToElement(elecreatediv6).click().build().perform();	
		Thread.sleep(2000);
    	driver.findElement(By.xpath("//li[contains(text(),'BABU')]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionProductMapGrid\"]/div[3]/table/tbody/tr[1]/td[1]/a[1]/span")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@id='btnBack']")).click();
    	Thread.sleep(2000);
    	//Work center with division Mapping
    	driver.findElement(By.xpath("//*[@id=\"DivisionGrid\"]/div[3]/table/tbody/tr[1]/td[4]/a")).click();
    	Thread.sleep(2000);
    	
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionWorkCenterGrid\"]/div[1]/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionWorkCenterGrid\"]/div[1]/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@id='WorkCenterID']")).sendKeys("1");
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@id=\"DivisionWorkCenterGrid\"]/div[3]/table/tbody/tr/td[1]/a[1]/span")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@id='btnBack']")).click();
		} catch (Exception e) {
		e.printStackTrace();
		}
    }
    
    /**
 	 * This method will click the ProductFamilyGroup link in the Header
 	 * @author Raja
 	 */
 	
 	/*public ProductFamilyGroup adminProductFamilyGroup() 
 	{
 		driver.findElement(By.xpath("//a[contains(text(),'Product Family Group')]")).click();
 		return new ProductFamilyGroup(driver);
 	}*/
	
}
	
	