package adminTestCases;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.BaseMaster;
import coalBase.BaseMethods;
import utilis.DataProviderCountry;
import utilis.DataProviderCurrency;
import utilis.DataProviderCustomer;
import utilis.DataProviderRegion;
import utilis.DataProviderUoM;

public class BaseMasterTC extends BaseMethods
{

	/**
	 * This method will fetch the Customer data from the Excel and pass it to the Customer fields
	 * @author Raja
	 */
	
	@DataProvider(name="Customer")
	public static Object[][] baseCustomer() throws Exception 
	{
		Object[][] arrayObject = DataProviderCustomer.readCustomerdata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Customer data to the Customer fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Customer", priority=1)
	public void customerPage(String data1, String data2, String data3) throws Exception
	{
		BaseMaster test = new BaseMaster(driver);
		test.createCustomername(data1);
		test.createCustomersnname(data2);
		test.createCustomerCategory(data3);	
	}
	
	/**
	 * This method will fetch the Currency data from the Excel and pass it to the Currency fields
	 * @author Raja
	 */
	
	@DataProvider(name="Currency")
	public static Object[][] baseCurrency() throws Exception 
	{
		Object[][] arrayObject = DataProviderCurrency.readCurrencydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Currency data to the Currency fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Currency", priority=2)
	public void currencyPage(String data1, String data2) throws Exception
	{
		BaseMaster currency = new BaseMaster(driver);
		currency.createCurrencyName(data1);
		currency.createCurrencySName(data2);
	}
	
	/**
	 * This method will fetch the Region data from the Excel and pass it to the Region fields
	 * @author Raja
	 */
	
	@DataProvider(name="Region")
	public static Object[][] baseRegion() throws Exception 
	{
		Object[][] arrayObject = DataProviderRegion.readRegiondata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Region data to the Region fields 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Region",priority=3)
	public void regionPage(String data1, String data2) throws Exception
	{
		BaseMaster region = new BaseMaster(driver);
		region.createRegionName(data1);
		region.createRegionSName(data2);
	}
	
	/**
	 * This method will fetch the Country data from the Excel and pass it to the Country fields
	 * @author Raja
	 */
	
	@DataProvider(name="Country")
	public static Object[][] baseCountry() throws Exception 
	{
		Object[][] arrayObject = DataProviderCountry.readCountrydata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Country data to the Country fields
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Country", priority=4)
	public void countryPage(String data1, String data2,String data3, String data4) throws Exception
	{
		BaseMaster country = new BaseMaster(driver);
		country.createCountryName(data1);
		country.createCountrySName(data2);
		country.createCountryLatitude(data3);
		country.createCountryLongitude(data4);
	}
	
	/**
	 * This method will fetch the UoM data from the Excel and pass it to the UoM fields
	 * @author Raja
	 */
	
	@DataProvider(name="UoM")
	public static Object[][] baseUoM() throws Exception 
	{
		Object[][] arrayObject = DataProviderUoM.readUoMdata();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Login data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="UoM", priority=5)
	public void uoMPage(String data1,String data2,String data3) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		BaseMaster uom = new BaseMaster(driver);
		uom.createUoMName(data1);
		uom.createUoMCode(data2);
		uom.createUoMDescription(data3);
		Thread.sleep(4000);
	}
}
