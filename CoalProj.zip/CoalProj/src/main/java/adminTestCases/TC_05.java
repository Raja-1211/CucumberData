package adminTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.ManufacturingRelationship;
import coalBase.BaseMethods;
import utilis.DPMR;

public class TC_05 extends BaseMethods
{
	@DataProvider(name="ManufacturingRelationship")
	public static Object[][] readMR() throws Exception 
	{
		Object[][] arrayObject = DPMR.readOperationMR();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ManufacturingRelationship", priority=1)
	public void readMRTC(String data1,String data2,String data3) throws Exception
	{
	Thread.sleep(2000);
	ManufacturingRelationship manufrel = new ManufacturingRelationship(driver);
	manufrel.manufacturingRelationshipadd();
	//manufrel.productcheckbox();
	manufrel.manufacturingRelationship(data1);
	manufrel.MROperations(data2);
	manufrel.autoComponent(data3);
	}
}
