package adminTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.Routing;
import coalBase.BaseMethods;
import utilis.DPRouting;

public class TC_06 extends BaseMethods
{
		
	@DataProvider(name="Routing")
	public static Object[][] readRouting() throws Exception 
	{
		Object[][] arrayObject = DPRouting.readRouting();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Routing", priority=1)
	public void readRoutingTC(String data1,String data2) throws Exception
	{
	Thread.sleep(2000);
	Routing route = new Routing(driver);
	route.routingAddbtn();
	route.routeName(data1);
	route.routeProduct(data2);
	//route.routeStatus(data3);
	route.expandAll();
	
	
	//route.expandAll();	
	//route.isTemplate(data4);
	//route.needFocusFactory(data5);
	//route.saveButton();
	
	}
}
