package adminTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.CreateModel;
import coalBase.BaseMethods;
import utilis.DPCreateModel;

public class TC_07 extends BaseMethods
{
	@DataProvider(name="CreateModel")
	public static Object[][] readCreateMod() throws Exception 
	{
		Object[][] arrayObject = DPCreateModel.readCreateModel();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="CreateModel", priority=1)
	public void readCreationModTC(String data1,String data2,String data3,String data4, String data5, String data6) throws Exception
	{
	CreateModel newmodel = new CreateModel(driver);
	Thread.sleep(2000);
	newmodel.CreateNewModelbutton();
	newmodel.CreateNewModelName(data1);
	newmodel.CreateNewModelDescription(data2);
	newmodel.CreateNewModelUoM();
	newmodel.CreateNewModelDivision();
	newmodel.CreateNewModelPlanningMethod(data3);
	newmodel.CreateNewModelNeedFocusFactory(data4);
	newmodel.CreateNewModelPeriodType(data5);
	newmodel.CreateNewModelPeriods(data6);	
	}
}
