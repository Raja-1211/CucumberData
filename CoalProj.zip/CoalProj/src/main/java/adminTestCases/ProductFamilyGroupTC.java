package adminTestCases;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import coalAdminPages.ProductFamilyGroup;
import coalBase.BaseMethods;
import utilis.DataProviderProduct;
import utilis.DataProviderProductFamily;
import utilis.DataProviderProductGroup;

public class ProductFamilyGroupTC extends BaseMethods
{

	/**
	 * This method will fetch the Product Group data from the Excel and pass it to the Product Group fields
	 * @author Raja
	 */
	
	@DataProvider(name="ProductGroup")
	public static Object[][] productGroupData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductGroup.readProductGroup();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Group data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductGroup", priority=1)
	public void ProductGroupPage(String data1,String data2) throws Exception
	{
	Thread.sleep(2000);
	ProductFamilyGroup prodgroup = new ProductFamilyGroup(driver);
	prodgroup.productGroupadd();
	prodgroup.productGroupName(data1);
	prodgroup.productGroupUoM(data2);
	}
	
	/**
	 * This method will fetch the Product Family data from the Excel and pass it to the Product Family fields
	 * @author Raja
	 */
	
	@DataProvider(name="ProductFamily")
	public static Object[][] productFamilyData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProductFamily.readProductFamily();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product Family data to the Product Family Method 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="ProductFamily", priority=2)
	public void ProductFamilyPage(String data1,String data2, String data3) throws Exception
	{
		ProductFamilyGroup prodfamily = new ProductFamilyGroup(driver);
		prodfamily.productFamilyadd();
		prodfamily.productFamilyName(data1);
		prodfamily.productFamilyUoM(data2);
		prodfamily.productFamilyGroup();
		prodfamily.productFamilyselect();
	}
	
	/**
	 * This method will fetch the Product data from the Excel and pass it to the Product fields
	 * @author Raja
	 */
	
	@DataProvider(name="Product")
	public static Object[][] productData() throws Exception 
	{
		Object[][] arrayObject = DataProviderProduct.readProduct();
		return arrayObject;
	}
	
	/**
	 * This method will pass the Product data to the Username and Password methods 
	 * @author Raja
	 * @throws Exception 
	 */
	
	@Test(dataProvider="Product")
	public void ProductPage(String data1,String data2, String data3, String data4, String data5, String data6, String data7, String data8, String data9, String data10, String data11,String data12,String data13) throws Exception
	{
		ProductFamilyGroup productdata = new ProductFamilyGroup(driver);
		productdata.ProductName(data1);
		productdata.ProductShortName(data2);
		productdata.Productdescription(data3);
		productdata.ProductUoM(data4);
		productdata.ProductCurrency(data5);
		productdata.Productfam(data6);
		productdata.ProductCategory(data7);
		productdata.ProductSAP(data8);
		productdata.Productlegacy(data9);
		productdata.ProductOnHandQuantity(data10);
		productdata.ProductStorage(data11);
		productdata.ProductTransportation(data12);
		productdata.ProductTesting(data13);
		productdata.ProductIsPhantom();	
	}	
}
