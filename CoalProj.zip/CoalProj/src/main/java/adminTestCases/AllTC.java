/*package adminTestCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import coalAdminPages.BaseMaster;
import coalBase.BaseMethods;

public class AllTC extends BaseMaster

{

	
	@BeforeTest
	public void startapp()
	{
		BaseMethods bmapp = new BaseMethods();
		bmapp.startApplication("Chrome");
	}
	
	@Test
	public void AllTestcase(String data1, String data2, String data3, String data4, String data5,String data6,String data7, String data8, String data9, String data10, String data11, String data12, String data13, String data14, String data15, String data16, String data17, String data18, String data19, String data20, String data21, String data22, String data23, String data24, String data25, String data26, String data27, String data28, String data29, String data30, String data31, String data32, String data33, String data34, String data35, String data36, String data37, String data38, String data39, String data40,String data41,String data42, String data43,String data44,String data45,String data46,String data47,String data48,String data49,String data50,String data51,String data52,String data53,String data54,String data55,String data56,String data57) throws Exception
	{
    	LoginTC lgn = new LoginTC();
    	lgn.LoginPage(data1, data2);
    	BaseMasterTC bm = new BaseMasterTC();
    	bm.customerPage(data3, data4, data5);
    	bm.currencyPage(data6, data7);
    	bm.regionPage(data8, data9);
    	bm.countryPage(data10, data11, data12, data13);
    	bm.uoMPage(data14, data15, data16);
    	ProductFamilyGroupTC pftc = new ProductFamilyGroupTC();
    	pftc.ProductGroupPage(data17, data18);
    	pftc.ProductFamilyPage(data19, data20, data21);
    	pftc.ProductPage(data22, data23, data24, data25, data26, data27, data28, data29, data30, data31, data32, data33, data34);
    	OperationWorkCenterTC owctc = new OperationWorkCenterTC();
    	owctc.readOperationGrouptc(data35);
    	owctc.readOperationtc(data36, data37, data38, data39, data40, data41);
    	owctc.readOperationTypetc(data42);
    	owctc.readOperationUnitConv(data42, data43, data44, data45, data46);
    	owctc.readOperationWctc(data47, data48);
    	ManufacturingRelationshipTC mrtc = new ManufacturingRelationshipTC();
    	mrtc.readMRTC(data47, data48, data49);
    	RoutingTC rtc = new RoutingTC();
    	rtc.readRoutingTC(data50, data51);
    	CreateNewModelTC cmtc = new CreateNewModelTC();
    	cmtc.readCreationModTC(data52, data53, data54, data55, data56, data57);
    }
}
*/