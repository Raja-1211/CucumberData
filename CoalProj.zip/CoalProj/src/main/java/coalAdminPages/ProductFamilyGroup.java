package coalAdminPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import adminTestCases.TC_04;
import coalBase.BaseMethods;



public class ProductFamilyGroup extends BaseMethods
{
	/**
	 * This method will initialize the web elements which are defined in Page Objects
	 * @author Raja
	 */
	public ProductFamilyGroup(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	/**
	 * These methods will create the new Product Group with the Product Group Name and UoM
	 * @throws Exception
	 * @author Raja
	 * @throws InterruptedException 
	 */	
 
	public void productGroupadd() throws InterruptedException
	{
		//Product Group Name
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(5000);
	    //Add Button
        driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[1]/a")).click();
	}
	
   public void productGroupName(String data1) throws InterruptedException
	{
    	
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}
	
	public void productGroupUoM(String data2) throws InterruptedException, IOException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
		
	/**
	 * These methods will create the new Product Family with the Product Family Name, UoM and linking the Product Group
	 * @throws Exception
	 * @author Raja
	 * @throws InterruptedException 
	 */	
    
	public void productFamilyadd() throws InterruptedException
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[1]/a")).click();
	}
 
	public void productFamilyName(String data1) throws InterruptedException
	{
		Thread.sleep(2000);
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys(data1);
	}	
	
 	public void productFamilyUoM(String data2) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
	}
	
  	public void productFamilyGroup() throws Exception
	{
		 //Product Family Name
	    driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span")).click();
 	   	Thread.sleep(3000);
 	    FileInputStream fis = new FileInputStream(new File("C:\\Users\\Raja.k\\git\\Coalrepository\\CoalCopy\\ExcelData\\DataExcelImport.xlsx"));
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet ws = wb.getSheetAt(6);
		XSSFSheet ws1 = wb.getSheetAt(7);
		int RowCount = ws.getLastRowNum()+1;
		
		int ColumnCount = ws.getRow(0).getLastCellNum();
		
		label:
		for(int k=2; k<RowCount; k++)
		{
		XSSFRow Row = ws.getRow(k);
		XSSFCell cell = Row.getCell(0);
		String cellValue = cell.toString();
		
		    int RowCount1 = ws1.getLastRowNum()+1;
		    for(int j=2;j<RowCount1;j++)
		    {
		      XSSFRow Row1 = ws1.getRow(j);
		      XSSFCell cell1 = Row1.getCell(2);
		      String cellValue1 = cell1.toString();
		      
		      	if(cellValue.equals(cellValue1))
		      		{
		      			WebElement test = driver.findElement(By.xpath("//*[@id='ProductGroupID_listbox']"));
		      			List<WebElement> options = test.findElements(By.tagName("li"));
		      			for (WebElement opt : options) 
		      			{
		      				if (opt.getText().equals(cellValue)) 
		      				{
		      					opt.click();
		      					break label;
		      				}
		      				
		      			}
		      		}
		     }
          }
}
  	
  	public void productFamilyselect()
  	{
		driver.findElement(By.xpath("//*[@id=\"productFamilyGrid\"]/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
	/**
	 * This method will create the new Product by passing the Product Name, SN, Currency, Product Family, Product Category, 10digit SAP, 11 digit legacy, On Hand Quantiy, Storage, Transportation and Testing data 
	 * @throws Exception
	 * @author Raja
	 */	
	
	public void ProductName(String data1) throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");
		Thread.sleep(5000);
		
		//Name
		 Thread.sleep(3000);
  	     driver.findElement(By.xpath("//*[@id='productGrid']/div[2]/div/table/thead/tr/th[7]/a[1]/span")).click();
  	     Thread.sleep(1000);
  	     driver.findElement(By.xpath("//input[@id='ProductName']")).sendKeys(data1);
  	     Thread.sleep(2000);
	}
	public void ProductShortName(String data2) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductShortName']")).sendKeys(data2);
		Thread.sleep(2000);
	}
	public void Productdescription(String data3) throws Exception
	{
		driver.findElement(By.xpath("//input[@id='ProductDescription']")).sendKeys(data3);
		Thread.sleep(2000);
	}
		//UOM
	public void ProductUoM(String data4) throws Exception
	{
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[10]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data4.equalsIgnoreCase("Ltr"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'Ltr')]")).click();
		}else
		{
			driver.findElement(By.xpath("//li[contains(text(),'EACH')]")).click();
		}
		Thread.sleep(2000);
	}
		//Currency
	public void ProductCurrency(String data5) throws Exception
	{
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[11]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data5.equalsIgnoreCase("Euro"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Euro')]")).click();
		}else
		  {
		   driver.findElement(By.xpath("//li[contains(text(),'AUD')]")).click();
		  }
		Thread.sleep(2000);
	}
		//Product Family
	public void Productfam(String data6) throws Exception
	{
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[12]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data6.equalsIgnoreCase("Sticky Coal Product Family"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Sticky Coal Product Family')]")).click();
		}else
		{
			driver.findElement(By.xpath("//li[contains(text(),'1006')]")).click();
		}
		Thread.sleep(2000);
	}
		//Product Category
	public void ProductCategory(String data7) throws Exception
	{
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[13]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		if(data7.equalsIgnoreCase("Finished Good"))
		{
		driver.findElement(By.xpath("//li[contains(text(),'Finished Good')]")).click();
		}else if(data7.equalsIgnoreCase("Semi-Finished Good"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'Semi-Finished Good')]")).click();
		}else if(data7.equalsIgnoreCase("Raw Material"))
		{
			driver.findElement(By.xpath("//li[contains(text(),'Raw Material')]")).click();
		}
		Thread.sleep(2000);
	}
	public void ProductSAP(String data8) throws Exception
	{
		//10 digit SAP
		driver.findElement(By.xpath("//input[@id='TenDigitSAPNumber']")).sendKeys(data8);
		Thread.sleep(2000);
	}
	public void Productlegacy(String data9) throws Exception
	{
		//11 digit Legacy
		driver.findElement(By.xpath("//input[@id='ElevenDigitSAPNumber']")).sendKeys(data9);
		Thread.sleep(2000);
	}
	public void ProductOnHandQuantity(String data10) throws Exception
	{
		//On Hand Quantiy
		driver.findElement(By.xpath("//input[@id='CurrentOnHandQuantity']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='CurrentOnHandQuantity']")).sendKeys(data10);
		Thread.sleep(2000);
	}
	public void ProductStorage(String data11) throws Exception
	{
		//Storage
		driver.findElement(By.xpath("//input[@id='Storage']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Storage']")).sendKeys(data11);
		Thread.sleep(2000);
	}
	public void ProductTransportation(String data12) throws Exception
	{
		//Transportation
		driver.findElement(By.xpath("//input[@id='Transportation']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Transportation']")).sendKeys(data12);
		Thread.sleep(2000);
	}
	public void ProductTesting(String data13) throws Exception
	{
		//Testing
		driver.findElement(By.xpath("//input[@id='Testing']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='Testing']")).sendKeys(data13);
		Thread.sleep(2000);
	}
	
	public void ProductIsPhantom() throws Exception
	{	
		//IsPhantom
		driver.findElement(By.xpath("//input[@id='IsPhantom']")).click();
		Thread.sleep(2000);
		//Tick Mark
		driver.findElement(By.xpath("//*[@id='productGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		Thread.sleep(2000);	
	}	
	
	/**
	 * This method will navigate to the Operation Work Center page from the Product Family Group page
	 * @throws Exception
	 * @author Raja
	 */	
	
	public OperationWorkCenter operationWc()
	{
		driver.findElement(By.xpath("//a[contains(text(),'Operation Work Center')]")).click();
		return new OperationWorkCenter(driver);
	}
	
}


