package coalPagesMyModels;

import coalBase.BaseMethods;

public class SetUp extends BaseMethods
{

	public void manufacturingRelationshipMR()
	{
		
	}
	
	public void routings()
	{
		
	}
	
	public void loadings()
	{
		
	}
	
	public void availableCapacity()
	{
		
	}
	
	
		
}
