package testingg;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import coalBase.BaseMethods;

public class Testing extends BaseMethods
{
	@Test(priority=1)
	public void testinggg() throws Exception
	{
		startApplication("Chrome");
		Thread.sleep(2000);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@id='UserName']")).sendKeys("A5G7QZZ");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Congruent2018!@#$");
		
		driver.findElement(By.xpath("//*[@id='divLoginForm']/form/div[7]/button")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//i[@class='fa fa-user fa-lg']")).click();
		driver.findElement(By.xpath("//a[contains(text(),'Product | Family | Group')]")).click();		
}
	@Test(priority=2)
	public void Productgroupadd() throws Exception
	{
		Thread.sleep(4000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(5000);
	    //Add Button
        driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[1]/a")).click();
        driver.findElement(By.xpath("//input[@id='Name']")).sendKeys("Sticky Coal");
        Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[6]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productGroupGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
		
	}
	
	@Test(priority=3)
	public void ProductFamilyadd() throws Exception
	{
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[1]/a")).click();
		Thread.sleep(2000);
	 	driver.findElement(By.xpath("//input[@id='Name']")).sendKeys("Product Family");
	 	Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[7]/span[1]/span/span[2]/span")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[contains(text(),'Rolls')]")).click();
		Thread.sleep(2000);
		WebElement test = driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[8]/span[1]/span/span[2]/span"));
		test.click();
		Thread.sleep(2000);
		test.sendKeys("Sticky Coal");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='productFamilyGrid']/div[3]/table/tbody/tr[1]/td[2]/a[1]/span")).click();
	}
	
}
